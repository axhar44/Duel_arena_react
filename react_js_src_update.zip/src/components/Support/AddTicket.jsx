import React from 'react'

const AddTicket = () => {
  return (
    <div>AddTicket</div>
  )
}

export default AddTicket