const Spinner = () => <div className="loader"></div>;

export default Spinner;
