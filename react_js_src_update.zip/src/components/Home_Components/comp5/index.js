import React from 'react'
import Frame2 from '../../../assets/img/Frame2.png' 
const Index = () => {
  return (
   
   <img src={Frame2} alt='frame2'/>
   
  )
}

export default Index