export function showChatRooms()
{
    return{
        type: "SHOW_CHAT_ROOMS"
    }
}

