import React from 'react'
import LootBreadCrum from '../components/LootBreadCrum'
const Loot = () => {
  return (
    <div className='mt-[40px]'>
      <LootBreadCrum/>
    </div>
  )
}

export default Loot